# coding: utf-8

def tag_():
    print('your tags are checked!')

def filename():
    print('your filenames are checked!')

def imagename():
    print('your imagenames are checked!')
