#!/usr/bin/env python3
# encoding=utf-8

def tag():
    print('your tags are checked!')

def filename():
    print('your filenames are checked!')

def imagename():
    print('your imagenames are checked!')
